public abstract class Passagem {
    private String nomePassageiro;
    private double valorTarifa;

    public Passagem(String nomePassageiro, double valorTarifa) {
        this.nomePassageiro = nomePassageiro;
        this.valorTarifa = valorTarifa;
    }

    public String getNomePassageiro() {
        return nomePassageiro;
    }

    public double getValorTarifa() {
        return valorTarifa;
    }

    public abstract String getModal();

    public abstract double calcularTaxaEmbarque();

    public abstract String getDocumentosExigidos();
}
