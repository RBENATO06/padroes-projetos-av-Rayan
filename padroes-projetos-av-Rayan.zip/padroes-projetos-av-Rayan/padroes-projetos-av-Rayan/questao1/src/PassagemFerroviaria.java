public class PassagemFerroviaria extends Passagem {
    public PassagemFerroviaria(String nomePassageiro, double valorTarifa) {
        super(nomePassageiro, valorTarifa);
    }

    @Override
    public String getModal() {
        return "Ferroviário";
    }

    @Override
    public double calcularTaxaEmbarque() {
        return getValorTarifa() * 0.05;
    }

    @Override
    public String getDocumentosExigidos() {
        return "Documento de identidade com foto e comprovante de reserva";
    }
}
