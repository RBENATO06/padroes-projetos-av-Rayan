public class PassagemAerea extends Passagem {
    public PassagemAerea(String nomePassageiro, double valorTarifa) {
        super(nomePassageiro, valorTarifa);
    }

    @Override
    public String getModal() {
        return "Aéreo";
    }

    @Override
    public double calcularTaxaEmbarque() {
        return getValorTarifa() * 0.08;
    }

    @Override
    public String getDocumentosExigidos() {
        return "Documento de identidade com foto e bilhete eletrônico (e-ticket)";
    }
}
