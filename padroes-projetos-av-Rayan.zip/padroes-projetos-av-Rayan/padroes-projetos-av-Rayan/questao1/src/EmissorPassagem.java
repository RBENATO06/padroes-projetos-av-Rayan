public abstract class EmissorPassagem {
    public abstract Passagem criarPassagem(String nomePassageiro, double valorTarifa);

    public void emitir(String nomePassageiro, double valorTarifa) {
        Passagem passagem = criarPassagem(nomePassageiro, valorTarifa);
        double taxaEmbarque = passagem.calcularTaxaEmbarque();
        System.out.println("Modal: " + passagem.getModal());
        System.out.println("Passageiro: " + passagem.getNomePassageiro());
        System.out.printf("Taxa de embarque: R$ %.2f%n", taxaEmbarque);
        System.out.println("Documentos exigidos: " + passagem.getDocumentosExigidos());
        System.out.println();
    }
}
