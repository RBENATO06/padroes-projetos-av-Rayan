public class PassagemRodoviaria extends Passagem {
    public PassagemRodoviaria(String nomePassageiro, double valorTarifa) {
        super(nomePassageiro, valorTarifa);
    }

    @Override
    public String getModal() {
        return "Rodoviário";
    }

    @Override
    public double calcularTaxaEmbarque() {
        return getValorTarifa() * 0.03;
    }

    @Override
    public String getDocumentosExigidos() {
        return "Documento de identidade com foto";
    }
}
