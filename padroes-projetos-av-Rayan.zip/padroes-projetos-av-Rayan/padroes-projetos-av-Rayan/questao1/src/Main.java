public class Main {
    public static void main(String[] args) {
        EmissorPassagem emissorAereo = new EmissorPassagemAerea();
        EmissorPassagem emissorRodoviario = new EmissorPassagemRodoviaria();
        EmissorPassagem emissorFerroviario = new EmissorPassagemFerroviaria();

        emissorAereo.emitir("Carlos Silva", 1200.00);
        emissorRodoviario.emitir("Mariana Souza", 180.00);
        emissorFerroviario.emitir("Roberto Lima", 250.00);
    }
}
