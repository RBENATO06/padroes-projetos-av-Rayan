public class EmissorPassagemFerroviaria extends EmissorPassagem {
    @Override
    public Passagem criarPassagem(String nomePassageiro, double valorTarifa) {
        return new PassagemFerroviaria(nomePassageiro, valorTarifa);
    }
}
