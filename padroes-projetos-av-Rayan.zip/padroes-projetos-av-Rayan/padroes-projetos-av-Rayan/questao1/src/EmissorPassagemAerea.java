public class EmissorPassagemAerea extends EmissorPassagem {
    @Override
    public Passagem criarPassagem(String nomePassageiro, double valorTarifa) {
        return new PassagemAerea(nomePassageiro, valorTarifa);
    }
}
