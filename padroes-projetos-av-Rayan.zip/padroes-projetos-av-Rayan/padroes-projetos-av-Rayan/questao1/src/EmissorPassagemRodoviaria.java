public class EmissorPassagemRodoviaria extends EmissorPassagem {
    @Override
    public Passagem criarPassagem(String nomePassageiro, double valorTarifa) {
        return new PassagemRodoviaria(nomePassageiro, valorTarifa);
    }
}
