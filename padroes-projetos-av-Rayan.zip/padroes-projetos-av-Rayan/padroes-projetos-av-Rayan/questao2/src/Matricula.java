public class Matricula {
    private MatriculaFactory factory;
    private DocumentoFiscal documentoFiscal;
    private Pagamento pagamento;
    private ComprovanteMatricula comprovanteMatricula;

    public Matricula(MatriculaFactory factory) {
        this.factory = factory;
    }

    public void confirmar() {
        this.documentoFiscal = factory.criarDocumentoFiscal();
        this.pagamento = factory.criarPagamento();
        this.comprovanteMatricula = factory.criarComprovanteMatricula();
    }

    public void imprimirRelatorio() {
        System.out.println(documentoFiscal.getDescricao());
        System.out.println(pagamento.getDescricao());
        System.out.println(comprovanteMatricula.getDescricao());
        System.out.println();
    }
}
