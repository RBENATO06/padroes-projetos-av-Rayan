public class Main {
    public static void main(String[] args) {
        Matricula matriculaBrasil = new Matricula(new BrasilMatriculaFactory());
        matriculaBrasil.confirmar();
        matriculaBrasil.imprimirRelatorio();

        Matricula matriculaChile = new Matricula(new ChileMatriculaFactory());
        matriculaChile.confirmar();
        matriculaChile.imprimirRelatorio();
    }
}
