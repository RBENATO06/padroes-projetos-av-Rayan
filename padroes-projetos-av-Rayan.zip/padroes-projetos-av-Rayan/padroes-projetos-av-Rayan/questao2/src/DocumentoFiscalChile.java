public class DocumentoFiscalChile implements DocumentoFiscal {
    @Override
    public String getDescricao() {
        return "Documento fiscal boleta electrónica com IVA de 19%";
    }
}
