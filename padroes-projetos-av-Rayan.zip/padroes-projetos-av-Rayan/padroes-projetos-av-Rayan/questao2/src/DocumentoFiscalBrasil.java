public class DocumentoFiscalBrasil implements DocumentoFiscal {
    @Override
    public String getDescricao() {
        return "Documento fiscal NFS-e com ISS de 5%";
    }
}
